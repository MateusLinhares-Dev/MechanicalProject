from django.apps import AppConfig


class ProductsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'products'
    verbose_name = 'Produto'
    verbose_name_plural = 'Produtos'

    def ready(self):
        import products.signals